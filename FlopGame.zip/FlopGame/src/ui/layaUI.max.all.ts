
import View=laya.ui.View;
import Dialog=laya.ui.Dialog;
module ui {
    export class EndDialogUI extends Dialog {
		public btnConfirm:Laya.Button;
		public lblTime:Laya.Label;

        public static  uiView:any ={"type":"Dialog","props":{"width":750,"height":1334},"child":[{"type":"Image","props":{"y":0,"x":0,"skin":"ui/end_bg.png"}},{"type":"Image","props":{"y":143,"x":93,"skin":"ui/end_bg2.png"}},{"type":"Button","props":{"y":845,"x":283,"var":"btnConfirm","stateNum":2,"skin":"ui/btn_end1.png","label":"\\"}},{"type":"Label","props":{"y":701,"x":178,"width":500,"var":"lblTime","text":"10.360秒","height":50,"fontSize":50,"color":"#5a3104","bold":true,"align":"center"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.EndDialogUI.uiView);

        }

    }
}

module ui {
    export class EndViewUI extends View {
		public btnConfirm:Laya.Button;
		public lblTime:Laya.Label;

        public static  uiView:any ={"type":"View","props":{"width":750,"height":1334},"child":[{"type":"Image","props":{"y":0,"x":0,"skin":"ui/end_bg.png"}},{"type":"Image","props":{"y":133,"x":83,"skin":"ui/end_bg2.png"}},{"type":"Button","props":{"y":835,"x":273,"var":"btnConfirm","stateNum":2,"skin":"ui/btn_end1.png","label":"\\"}},{"type":"Label","props":{"y":691,"x":175,"width":500,"var":"lblTime","text":"1分36秒","height":50,"fontSize":50,"color":"#5a3104","bold":true,"align":"center"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.EndViewUI.uiView);

        }

    }
}

module ui {
    export class GameViewUI extends View {
		public imgFive:Laya.Image;
		public btnAgain:Laya.Button;
		public btnPlay:Laya.Button;
		public btnRank:Laya.Button;
		public lblCountdown:Laya.Label;

        public static  uiView:any ={"type":"View","props":{"width":750,"height":1334},"child":[{"type":"Image","props":{"y":0,"x":0,"skin":"ui/game_bg.png"}},{"type":"Image","props":{"y":330,"x":83,"var":"imgFive","skin":"ui/game2.png"}},{"type":"Button","props":{"y":1090,"x":86,"var":"btnAgain","stateNum":2,"skin":"ui/btn_game1.png","bottom":124}},{"type":"Button","props":{"x":86,"var":"btnPlay","stateNum":2,"skin":"ui/btn_game2.png","bottom":124}},{"type":"Button","props":{"var":"btnRank","stateNum":2,"skin":"ui/btn_game3.png","right":86,"bottom":124}},{"type":"Label","props":{"y":967,"x":122,"width":500,"var":"lblCountdown","text":"0","height":75,"fontSize":75,"color":"#ffffff","bold":true,"align":"center"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.GameViewUI.uiView);

        }

    }
}

module ui {
    export class LoadingViewUI extends View {
		public loadingBar:Laya.ProgressBar;
		public loadingFlag:Laya.Image;

        public static  uiView:any ={"type":"View","props":{"width":750,"height":1334},"child":[{"type":"Image","props":{"y":0,"x":0,"skin":"loading/loading_bg.png"}},{"type":"Image","props":{"y":963,"x":158,"skin":"loading/loading2.png"}},{"type":"ProgressBar","props":{"y":1103,"x":47,"var":"loadingBar","value":1,"skin":"loading/progress_load.png","sizeGrid":"0,10,0,10"}},{"type":"Image","props":{"y":1152,"x":276,"skin":"loading/loading1.png"}},{"type":"Image","props":{"y":1047,"x":102,"var":"loadingFlag","skin":"loading/loading3.png"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.LoadingViewUI.uiView);

        }

    }
}

module ui {
    export class RankViewUI extends View {
		public boxContent:Laya.Box;
		public btnClose:Laya.Button;
		public itemList:Laya.List;
		public imgSelf:Laya.Image;

        public static  uiView:any ={"type":"View","props":{"width":750,"height":1334},"child":[{"type":"Image","props":{"y":0,"x":0,"skin":"ui/end_bg.png"}},{"type":"Box","props":{"y":2,"x":28,"var":"boxContent"},"child":[{"type":"Image","props":{"skin":"ui/rank_bg.png"}},{"type":"Button","props":{"y":116,"x":605,"var":"btnClose","stateNum":2,"skin":"ui/btn_rank1.png"}},{"type":"List","props":{"y":267,"x":67,"var":"itemList"},"child":[{"type":"Box","props":{"y":0,"x":0,"visible":false,"renderType":"render"},"child":[{"type":"Image","props":{"x":3,"skin":"ui/rank8.png","name":"imgItem"},"child":[{"type":"Image","props":{"skin":"ui/rank9.png","name":"imgBg"}},{"type":"Image","props":{"y":26,"x":-3,"skin":"ui/rank1.png","name":"imgRank"}},{"type":"Image","props":{"y":30,"x":33,"skin":"ui/rank4.png","name":"imgCurrent"}},{"type":"Image","props":{"y":13,"x":103,"skin":"ui/rank6.png"}},{"type":"Image","props":{"y":19,"x":107,"skin":"ui/head1.png","scaleY":0.5,"scaleX":0.5,"name":"imgHead"}},{"type":"Label","props":{"y":43,"x":416,"width":130,"text":"100.36秒","name":"lblTime","height":25,"fontSize":25,"color":"#ffad00","bold":false}},{"type":"Image","props":{"y":35,"x":382,"skin":"ui/rank7.png"}},{"type":"Label","props":{"y":35,"x":21,"width":70,"text":"4th","name":"lblRank","height":40,"fontSize":40,"color":"#ffad00","align":"center"}},{"type":"Label","props":{"y":43,"x":186,"width":160,"text":"是发额外若翁","name":"lblName","height":25,"fontSize":25,"color":"#ffad00","bold":false}}]}]}]},{"type":"Image","props":{"y":1003,"x":73,"skin":"ui/rank5.png"}},{"type":"Image","props":{"y":1029,"x":71,"var":"imgSelf","skin":"ui/rank8.png"},"child":[{"type":"Image","props":{"skin":"ui/rank9.png","name":"imgBg"}},{"type":"Image","props":{"y":26,"x":-3,"skin":"ui/rank1.png","name":"imgRank"}},{"type":"Image","props":{"y":30,"x":33,"skin":"ui/rank4.png","name":"imgCurrent"}},{"type":"Image","props":{"y":13,"x":103,"skin":"ui/rank6.png"}},{"type":"Image","props":{"y":19,"x":107,"skin":"ui/head1.png","scaleY":0.5,"scaleX":0.5,"name":"imgHead"}},{"type":"Label","props":{"y":43,"x":416,"width":130,"text":"1分36秒","name":"lblTime","height":25,"fontSize":25,"color":"#ffad00","bold":false}},{"type":"Image","props":{"y":35,"x":382,"skin":"ui/rank7.png"}},{"type":"Label","props":{"y":35,"x":21,"width":70,"text":"4th","name":"lblRank","height":40,"fontSize":40,"color":"#ffad00","align":"center"}},{"type":"Label","props":{"y":43,"x":186,"width":160,"text":"阿斯蒂芬地方","name":"lblName","height":25,"fontSize":25,"color":"#ffad00","bold":false}}]}]}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.RankViewUI.uiView);

        }

    }
}

module ui {
    export class SelcetViewUI extends View {
		public btnDifficulty:Laya.Button;
		public btnSimple:Laya.Button;
		public btnSelect:Laya.Button;
		public headBax:Laya.Box;
		public txtInput:Laya.TextInput;
		public btnRandom:Laya.Button;

        public static  uiView:any ={"type":"View","props":{"width":750,"height":1334},"child":[{"type":"Image","props":{"y":0,"x":0,"skin":"ui/select_bg.png"}},{"type":"Button","props":{"y":1025,"var":"btnDifficulty","stateNum":2,"skin":"ui/btn_select1.png","right":130}},{"type":"Button","props":{"y":1025,"var":"btnSimple","stateNum":2,"skin":"ui/btn_select2.png","left":130}},{"type":"Button","props":{"y":1158,"x":254,"var":"btnSelect","stateNum":2,"skin":"ui/btn_select4.png"}},{"type":"Box","props":{"y":221,"x":106,"var":"headBax"},"child":[{"type":"Button","props":{"stateNum":2,"skin":"ui/btn_select3.png","name":"item0"}},{"type":"Image","props":{"y":14,"x":11,"skin":"ui/head1.png","name":"img0"}},{"type":"Button","props":{"x":186,"stateNum":2,"skin":"ui/btn_select3.png","name":"item1"}},{"type":"Image","props":{"y":14,"x":197,"skin":"ui/head2.png","name":"img1"}},{"type":"Button","props":{"x":372,"stateNum":2,"skin":"ui/btn_select3.png","name":"item2"}},{"type":"Image","props":{"y":14,"x":383,"skin":"ui/head3.png","name":"img2"}},{"type":"Button","props":{"y":192,"stateNum":2,"skin":"ui/btn_select3.png","name":"item3"}},{"type":"Image","props":{"y":206,"x":11,"skin":"ui/head4.png","name":"img3"}},{"type":"Button","props":{"y":192,"x":186,"stateNum":2,"skin":"ui/btn_select3.png","name":"item4"}},{"type":"Image","props":{"y":206,"x":197,"skin":"ui/head5.png","name":"img4"}},{"type":"Button","props":{"y":192,"x":372,"stateNum":2,"skin":"ui/btn_select3.png","name":"item5"}},{"type":"Image","props":{"y":206,"x":383,"skin":"ui/head6.png","name":"img5"}}]},{"type":"Image","props":{"y":778,"x":169,"skin":"ui/select_input.png"},"child":[{"type":"TextInput","props":{"y":-1,"x":4,"width":260,"var":"txtInput","maxChars":6,"height":80,"fontSize":30,"bold":true,"align":"center"}}]},{"type":"Button","props":{"y":767,"x":460,"var":"btnRandom","stateNum":2,"skin":"ui/btn_select5.png"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.SelcetViewUI.uiView);

        }

    }
}
