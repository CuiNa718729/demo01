
class RankView extends ui.RankViewUI {
    private headIndex:number;
    private timedTime:number;
    private isCompleteGame:boolean;
    private selfRanking:number;
    private playerName:string = "";
    constructor(headIndex:number , timedTime:number , type:number , isCompleteGame:boolean , playerName:string) {
        super();
        this.headIndex = headIndex;
        this.timedTime = timedTime;
        this.isCompleteGame = isCompleteGame;
        this.playerName = playerName;
        this.imgSelf.visible = false;

        this.itemList.repeatX = 1;
        this.itemList.repeatY = 6;
        this.itemList.vScrollBarSkin = "";
        this.itemList.selectEnable = true;
        this.itemList.spaceY = 10;
        this.itemList.scrollBar.elasticBackTime = 200;//设置橡皮筋回弹时间。单位为毫秒。
        this.itemList.scrollBar.elasticDistance = 50;//设置橡皮筋极限距离
        this.itemList.selectHandler = Laya.Handler.create(this,this.onSelect,null,false);
        this.itemList.renderHandler = Laya.Handler.create(this,this.updateItem,null,false);

        this.btnClose.on(Laya.Event.CLICK,this,function(){
            this.dismiss();
        });

        if (this.isCompleteGame == false){
            this.timedTime = 0;
        }
        
        //请求排行榜
        console.log("rankData:" + Laya.LocalStorage.getJSON("rankData"));

        if (Laya.LocalStorage.getJSON("rankData") != null){
            this.completeHandler(Laya.LocalStorage.getJSON("rankData"));
        }else{
            var data = {
                "score" : this.timedTime,
                "avatar" : "ui/head" + this.headIndex + ".png",
                "type" : type,
                "userName" : this.playerName
            };
            WebService.getInstance().request(Consts.H_RankingList,data,this,this.completeHandler);
        }

        this.boxContent.y -= this.boxContent.height;
        Laya.Tween.to(this.boxContent,{y:2},500,Laya.Ease.backOut);
    }
    
    //List选择
    onSelect(index:number):void{

    }

    //更新Item
    updateItem(item:Laya.Box , index:number):void{
        var imgItem:Laya.Image = item.getChildByName("imgItem") as Laya.Image;
        var imgBg:Laya.Image = imgItem.getChildByName("imgBg") as Laya.Image;
        imgBg.visible = false;

        var imgRank:Laya.Image = imgItem.getChildByName("imgRank") as Laya.Image;
        imgRank.visible = false;

        var imgCurrent:Laya.Image = imgItem.getChildByName("imgCurrent") as Laya.Image;
        imgCurrent.visible = false;

        var lblTime:Laya.Label = imgItem.getChildByName("lblTime") as Laya.Label;
        this.timeFormat(item.dataSource["score"],lblTime);

        var lblRank:Laya.Label = imgItem.getChildByName("lblRank") as Laya.Label;
        lblRank.visible = false;

        var imgHead:Laya.Image = imgItem.getChildByName("imgHead") as Laya.Image;
        imgHead.skin = item.dataSource["avatar"];

        var lblName:Laya.Label = imgItem.getChildByName("lblName") as Laya.Label;
        lblName.text = item.dataSource["userName"];
            
        if ((index + 1) == this.selfRanking){
            imgBg.visible = true;
        }

        if (index < 3){
            imgRank.visible = true;
            imgRank.skin = "ui/rank"+(index+1)+".png";
        }else{
            lblRank.visible = true;
            lblRank.text = (index+1)+"th";
        }
    }

    private completeHandler(data:any):void{
        var meta:any = data["meta"];
        var content = data["data"];
        if (meta == null || content == null){
            return;
        }
        if (meta["code"] != 0){
            return;
        }
        if (this.isCompleteGame){
            Laya.LocalStorage.setJSON("rankData",data);
        }

        this.selfRanking = content["ranking"];
        this.itemList.array = content["rankingList"];

        this.fillSelfData();
    }

    //填充数据
    fillSelfData(){
        this.imgSelf.visible = true;

        var imgBg:Laya.Image = this.imgSelf.getChildByName("imgBg") as Laya.Image;
        imgBg.visible = false;

        var imgRank:Laya.Image = this.imgSelf.getChildByName("imgRank") as Laya.Image;
        imgRank.visible = false;

        var imgCurrent:Laya.Image = this.imgSelf.getChildByName("imgCurrent") as Laya.Image;
        imgCurrent.visible = true;

        var lblTime:Laya.Label = this.imgSelf.getChildByName("lblTime") as Laya.Label;
        this.timeFormat(this.timedTime,lblTime);

        var lblRank:Laya.Label = this.imgSelf.getChildByName("lblRank") as Laya.Label;
        lblRank.visible = false;

        var imgHead:Laya.Image = this.imgSelf.getChildByName("imgHead") as Laya.Image;
        imgHead.skin = "ui/head" + this.headIndex + ".png";

        var lblName:Laya.Label = this.imgSelf.getChildByName("lblName") as Laya.Label;
        lblName.text = this.playerName;
    }

    //时间格式化
    timeFormat(time:number,lblTime:Laya.Label){
        lblTime.text = Tools.matchTimeFormat(time)
    }

    //释放
    dismiss(){
        this.removeSelf();
    }


}