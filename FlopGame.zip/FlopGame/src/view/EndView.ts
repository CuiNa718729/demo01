
class EndView extends ui.EndViewUI {
    constructor() {
        super();
        this.btnConfirm.on(Laya.Event.CLICK,this,function(){
            this.dismiss();
        });
    }

    dismiss(){
        this.removeSelf();
    }
}