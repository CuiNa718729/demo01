
class EndDialog extends ui.EndDialogUI {
    constructor(time:number) {
        super();
        this.btnConfirm.on(Laya.Event.CLICK,this,function(){
            this.dismiss();
        });
        
        this.lblTime.text = Tools.matchTimeFormat(time)
    }

    dismiss(){
        this.removeSelf();
    }
}