
/**
 * 加载页
 */
class LoadingView extends ui.LoadingViewUI {
    private loadingEndHandler:Laya.Handler = null;
    constructor(handler:Laya.Handler) {
        super();
        this.loadingBar.value = 0;
        this.loadingEndHandler = handler;

        var resArray:Array<any>=[
            {url:"res/atlas/ui.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/emblem.atlas",type:Laya.Loader.ATLAS},
            {url:"ui/select_bg.png",type:Laya.Loader.IMAGE},
            {url:"ui/game_bg.png",type:Laya.Loader.IMAGE},
            {url:"ui/game2.png",type:Laya.Loader.IMAGE},
            {url:"ui/end_bg.png",type:Laya.Loader.IMAGE},
            {url:"ui/end_bg2.png",type:Laya.Loader.IMAGE},
            {url:"ui/rank_bg.png",type:Laya.Loader.IMAGE},
            {url:"ui/rank5.png",type:Laya.Loader.IMAGE},
            {url:"ui/rank8.png",type:Laya.Loader.IMAGE},
            {url:"ui/rank9.png",type:Laya.Loader.IMAGE},
            {url:"sound/attraction.mp3",type:Laya.Loader.SOUND},
            {url:"text/textName.txt",type:Laya.Loader.TEXT}
        ];
        Laya.loader.load(resArray,Laya.Handler.create(this,this.onLoaded),Laya.Handler.create(this,this.onProgress,null,false));
    }

    //加载
    onLoaded():void{
        Laya.SoundManager.playMusic("sound/attraction.mp3", 0);
        this.dismiss();
    }

    //加载过程
    onProgress(progress:number):void{
        //console.log(progress);
        this.loadingBar.value = progress;
        var moveX = this.loadingBar.x + this.loadingBar.width * this.loadingBar.value;
        this.loadingFlag.x = moveX - 15;
    }

    dismiss():void{
        this.removeSelf();
        this.loadingEndHandler.run();
    }
    
}