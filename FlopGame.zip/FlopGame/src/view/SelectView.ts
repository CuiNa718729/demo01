
/**
 * 选择页面
 */
class SelectView extends ui.SelcetViewUI {
    private modeType:number = 1;//1是简单模式 ，2是困难模式
    private selectHeadNum:number = 1;
    private selectBtn:Laya.Button;
    private totalCount:number = 16; //头像总数
    private needCount:number = 6; //需要数量
    private randomHeads:Array<number>;//随机显示的会徽

    private selectEndHandler:Laya.Handler = null;
    constructor(handler:Laya.Handler) {
        super();
        this.selectEndHandler = handler;
        this.randomHeads = new Array<number>();
        Tools.randomNoRepetition(this.randomHeads , this.totalCount , this.needCount);

        for(var i:number = 0 ; i < this.needCount ; i++){
            var btnHead:Laya.Button = this.headBax.getChildByName("item" + i) as Laya.Button;
            if(i == 0){
                btnHead.selected = true;
                this.selectBtn = btnHead;
            }
            var imgHead:Laya.Image = this.headBax.getChildByName("img" + i) as Laya.Image;
            imgHead.skin = "ui/head"+(this.randomHeads[i] + 1)+".png";
            btnHead.on(Laya.Event.CLICK,this,this.headSelectClickHandler,[btnHead,(this.randomHeads[i] + 1)]);
        }

        this.btnSimple.selected = true;

        //简单模式
        this.btnSimple.on(Laya.Event.CLICK,this,function(){
            this.btnSimple.selected = true;
            this.btnDifficulty.selected = false;
            this.modeType = 1;
        });

        //困难模式
        this.btnDifficulty.on(Laya.Event.CLICK,this,function(){
            this.btnSimple.selected = false;
            this.btnDifficulty.selected = true;
            this.modeType = 2;
        });

        //选择进入游戏
        this.btnSelect.on(Laya.Event.CLICK,this,function(){
            this.dismiss()
        });

        //名称
        var textName:string = Laya.Loader.getRes("text/textName.txt");
        var names:string[] = textName.split(",");
        var randomName = "";
        if (FlopGame.playerName != ""){
            this.txtInput.text = FlopGame.playerName;
        }
        else{
            randomName = names[Math.floor(Math.random() * names.length)];
            this.txtInput.text = randomName;
        }
        
        this.btnRandom.on(Laya.Event.CLICK,this,function(){
            randomName = names[Math.floor(Math.random() * names.length)];
            this.txtInput.text = randomName;
        })
        
    }

    //点击头像处理
    headSelectClickHandler(headBtn:any,index:number):void{
        this.selectBtn.selected = false;
        (headBtn as Laya.Button).selected = true;
        this.selectBtn = (headBtn as Laya.Button);
        this.selectHeadNum = index;
    }

    dismiss():void{
        this.removeSelf();
        FlopGame.playerName = this.txtInput.text;
        this.selectEndHandler.runWith([this.modeType , this.selectHeadNum , this.txtInput.text]);

        // this.selectBtn.selected = false;
        // this.selectBtn = this.headBax.getChildByName("item0") as Laya.Button;
        // this.selectBtn.selected = true;

        // this.btnSimple.selected = true;
        // this.btnDifficulty.selected = false;
        // this.modeType = 1;
        // this.selectHeadNum = 0;
    }
}