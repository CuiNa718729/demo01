
/**
 * 游戏逻辑处理
 */
class GameView extends ui.GameViewUI {

    private gameEndHandler:Laya.Handler = null;
    private modeType:number = 1;
    private headIndex:number = 1;
    private cardArray:Array<any>; //卡牌资源集合
    private numArray:Array<number>;
    private successNum:number = 0; //已成功翻牌次数
    private selectCardArr:Array<Laya.Image>;
    private memoryTime:number = 10; //记忆时间
    private emblemCount:number = 24;//会徽总数量
    private randomEmblems:Array<number>;//随机显示的会徽
    private timedTime:number = 0;//计时时间
    private isCompleteGame:boolean = false;//当前游戏是否结束
    private useTime:number = 0; 
    private playerName:string = "";//玩家名称

    constructor(handler:Laya.Handler , modeType:number , headIndex:number , playerName:string) {
        super();
        this.gameEndHandler = handler;
        this.modeType = modeType;
        this.headIndex = headIndex;
        this.playerName = playerName;

        this.cardArray = new Array<any>();
        this.numArray = new Array<number>();
        this.selectCardArr = new Array<Laya.Image>();
        this.randomEmblems = new Array<number>();

        this.imgFive.zOrder = 2;
        
        this.btnPlay.visible = true;
        this.btnAgain.visible = false;
        
        //重新开始
        this.btnAgain.on(Laya.Event.CLICK,this,function(){
            this.dismiss();
        });

        //开始游戏
        this.btnPlay.on(Laya.Event.CLICK,this,function(){
            this.btnPlay.visible = false;
            this.btnAgain.visible = true;
            this.openAllCards();
            Laya.timer.loop(1000,this,this.onMemoryLoop);
        })

        //排行榜
        this.btnRank.on(Laya.Event.CLICK,this,function(){
            var rankView:RankView = new RankView(this.headIndex , this.useTime , this.modeType , this.isCompleteGame , this.playerName);
            rankView.zOrder = 4;
            this.addChild(rankView);
        });

        if(this.modeType == 1){
            this.simpleMode();
        }else{
            this.difficultyMode();
            this.imgFive.visible = false;
        }
        this.lblCountdown.text = this.memoryTime.toString();
    }

    //记忆时间
    onMemoryLoop():void{
        if(this.memoryTime == 1){
            this.closeAllCards();
            Laya.timer.clear(this,this.onMemoryLoop);

            Laya.timer.loop(1000,this,this.onGameLoop);
            this.useTime = new Date().getTime();
        }
        this.memoryTime -= 1;
        this.lblCountdown.text = this.memoryTime.toString();
    }

    //游戏时间
    onGameLoop():void{
        this.timedTime += 1;
        this.lblCountdown.text = this.timedTime.toString();
        if(this.successNum >= this.cardArray.length){
            Laya.timer.clear(this,this.onGameLoop);
            this.isCompleteGame = true;
            Laya.timer.once(300,this,this.onOverLoop);
            this.useTime = new Date().getTime() - this.useTime;
        }

    }

    //结束游戏
    onOverLoop():void{
        var endView:EndDialog = new EndDialog(this.useTime);
        this.addChild(endView);
        endView.zOrder = 4;
        Laya.timer.clear(this,this.onOverLoop);
        for(var i:number = 0 ; i < this.cardArray.length ; i++){
            this.cardArray[i].visible = true;
            this.cardArray[i].scaleY = 1;
        }

    }

    //掀开所有的牌
    openAllCards(){
        for(var i:number = 0 ; i < this.cardArray.length ; i++){
            this.flopAnimation(this.cardArray[i] , Laya.Handler.create(this,function(card:Laya.Image,index:number){
                card.skin = "emblem/" + (this.modeType > 1 ? "difficulty":"simple") + this.numArray[index] + ".png";
                card.zOrder = 3;
                card.mouseEnabled = false;
            },[this.cardArray[i],i]),100);
        }
    }

    //盖上所有的牌
    closeAllCards(){
        for(var i:number = 0 ; i < this.cardArray.length ; i++){
            this.flopAnimation(this.cardArray[i] , Laya.Handler.create(this,function(card:Laya.Image,index:number){
                card.skin = "ui/game" + (this.modeType > 1 ? 5:6) + ".png";
                card.zOrder = 1;
                card.mouseEnabled = true;
            },[this.cardArray[i],i]),100);
        }
    }

    //简单模式
    simpleMode():void{
        var count:number = 6;
        this.randomEmblem(count);

        var x:number = 163;
        var y:number = 167;
        for(var i:number = 0 ; i < count*2 ; i++){
            var img:Laya.Image = new Laya.Image();
            img.skin = "ui/game6.png";
            img.anchorX = 0.5;
            img.anchorY = 0.5;
            img.mouseEnabled = false;
            this.addChild(img);
            img.pos(x,y);
            this.cardArray.push(img);
            x = img.x + img.width + 25;
            if(this.cardArray.length % 3 == 0){
                x = 163;
                y = img.y + img.height + 25;
            }
            img.on(Laya.Event.CLICK,this,this.flopHandler,[img , i]);
        }
    }

    //困难模式
    difficultyMode():void{
        var count:number = 10;
        this.randomEmblem(count);

        var x:number = 143;
        var y:number = 150;
        for(var i:number = 0 ; i < count*2 ; i++){
            var img:Laya.Image = new Laya.Image();
            img.skin = "ui/game5.png";
            img.anchorX = 0.5;
            img.anchorY = 0.5;
            img.mouseEnabled = false;
            this.addChild(img);
            img.pos(x,y);
            this.cardArray.push(img);
            x = img.x + img.width + 20;
            if(this.cardArray.length % 4 == 0){
                x = 143;
                y = img.y + img.height + 20;
            }
            img.on(Laya.Event.CLICK,this,this.flopHandler,[img , i]);
        }
    }

    //获取不重复的随机会徽
    randomEmblem(count:number){
        Tools.randomNoRepetition(this.randomEmblems,this.emblemCount,count);
        this.randomOrdering();
    }

    //随机排序
    randomOrdering():void{
        for(var i:number = 0 ; i < this.randomEmblems.length ; i++){
            this.numArray.push(this.randomEmblems[i]);
            this.numArray.push(this.randomEmblems[i]);
        }
        //随机排序
        this.numArray.sort(function(){ return 0.5 - Math.random() })
    }

    //翻牌
    flopHandler(sImg:Laya.Image , index:number):void{
        sImg.tag = this.numArray[index];
        this.flopAnimation(sImg , Laya.Handler.create(this,function(){
            sImg.skin = "emblem/" + (this.modeType > 1 ? "difficulty":"simple") + this.numArray[index] + ".png";
            sImg.zOrder = 3;
            sImg.mouseEnabled = false;
            this.flopCallBack(sImg);
        }));
    }

    //翻牌回调
    flopCallBack(sImg:Laya.Image){
        if (this.selectCardArr.length <= 0){
            this.selectCardArr.push(sImg);
        }
        else if (this.selectCardArr.length == 1){
            if (this.selectCardArr[0].tag == sImg.tag){
                var card:Laya.Image = this.selectCardArr.shift();
                Laya.Tween.to(card,{alpha:0 , scaleY:0},500,Laya.Ease.backIn,Laya.Handler.create(this,function(){
                    card.visible = false;
                    card.alpha = 1;
                    card = null;
                }));

                Laya.Tween.to(sImg,{alpha:0 , scaleY:0},500,Laya.Ease.backIn,Laya.Handler.create(this,function(){
                    sImg.visible = false;
                    sImg.alpha = 1;
                    sImg = null;
                }));
                this.successNum += 2;
            } 
            else{
                this.selectCardArr.push(sImg);
            }
        }
        else if (this.selectCardArr.length == 2){
            for (var i:number = 0 ; i < 2 ; i++){
                this.reductionHandler();
            }
            this.selectCardArr.push(sImg);
        }
    }

    //还原
    reductionHandler(){
        if (this.selectCardArr.length <= 0 ){
            return;
        }
        var card:Laya.Image = this.selectCardArr.shift();
        this.flopAnimation(card,Laya.Handler.create(this,function(){
            card.skin = "ui/game" + (this.modeType > 1 ? 5:6) + ".png";
            card.zOrder = 1;
            card.mouseEnabled = true;
            card = null;
        }));
    }
    
    //翻牌动画
    flopAnimation(card:Laya.Image , callBack:Laya.Handler , delay:number = 0){
        Laya.Tween.to(card,{scaleX:card.scaleX*-1},200 + delay,null,callBack);
    }

    //
    dismiss():void{
        Laya.timer.clear(this,this.onMemoryLoop);
        Laya.timer.clear(this,this.onGameLoop);
        Laya.timer.clear(this,this.onOverLoop);
        this.gameEndHandler.run();
        Laya.LocalStorage.removeItem("rankData");
        this.removeSelf();
    }

}