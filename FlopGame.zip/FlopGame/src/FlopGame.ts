// 程序入口
class FlopGame{
    public static playerName:string = "";
    constructor(){
        Laya.MiniAdpter.init();
        
        Laya.init(750,1336);

        //屏幕适配设置
        Laya.stage.scaleMode = Laya.Stage.SCALE_SHOWALL;
        Laya.stage.alignH = Laya.Stage.ALIGN_CENTER;
        Laya.stage.alignV = Laya.Stage.ALIGN_CENTER;
        Laya.stage.screenMode = Laya.Stage.SCREEN_VERTICAL;
        Laya.stage.bgColor = "#ffffff";

        Laya.LocalStorage.removeItem("rankData");

        //加载图片
        var loadingArray:Array<any> = [
            {url:"ui/loading_bg.png",type:Laya.Loader.IMAGE},
            {url:"ui/progress_load.png",type:Laya.Loader.IMAGE},
            {url:"ui/progress_load$bar.png",type:Laya.Loader.IMAGE},
            {url:"res/atlas/loading.atlas",type:Laya.Loader.ATLAS}
        ];
        Laya.loader.load(loadingArray,Laya.Handler.create(this,this.onLoaded));
    }

    //资源加载结束
    onLoaded():void{
        var loadingEndHandler:Laya.Handler = Laya.Handler.create(this,this.enterSelectPage,null,false);
        var loading:LoadingView = new LoadingView(loadingEndHandler);
        Laya.stage.addChild(loading);
    }
    //进入选择页
    enterSelectPage():void{
        var selectEndHandler:Laya.Handler = Laya.Handler.create(this,this.enterGamePage,null,false);
        var selectView:SelectView = new SelectView(selectEndHandler);
        Laya.stage.addChild(selectView);
    }
    //进入游戏页面
    enterGamePage(modeType:number , headIndex:number , playerName:string):void{
        var gameEndHandler:Laya.Handler = Laya.Handler.create(this,this.enterSelectPage,null,false);
        var gameView:GameView = new GameView(gameEndHandler , modeType , headIndex , playerName);
        Laya.stage.addChild(gameView);
    }
}
new FlopGame();