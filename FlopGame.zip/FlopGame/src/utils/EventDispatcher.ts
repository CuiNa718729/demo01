
/**
 * 事件派发器
*/
class EventDispatcher {
    private static instance:EventDispatcher = null;
    private dicHandler:Array<any>;

    constructor() {
        this.dicHandler = new Array<any>();
    }

    //获取单利对象
    public static getInstance():EventDispatcher{
        if(EventDispatcher.instance == null)
            EventDispatcher.instance = new EventDispatcher();
        return EventDispatcher.instance;
    }

    //添加所关心的事件
    public addListener(target:string, eventId:string, listener:Laya.Handler, args:any):void{
        if (this.dicHandler[target] == null){
            this.dicHandler[target] = new Array<any>();
            this.dicHandler[target][eventId] = new Array<any>();
        }
        this.dicHandler[target][eventId].push(listener);
        this.dicHandler[target][eventId].push(args);
    }

    //移除监听的事件
    public removeListener(target:string, eventId:string):void{
        this.dicHandler[target][eventId] = null;
    }

    //移除当前类的所有事件
    public removeAllListener(target:string):void{
        for(var key in this.dicHandler[target]){
            this.dicHandler[target][key] = null;
        }
        this.dicHandler[target] = null;
    }

    //触发事件
    public dispatch(eventId:string):void{
        for(var targetKey in this.dicHandler){
            var values = this.dicHandler[targetKey];
            for (var eventKey in values){
                if (eventId == eventKey){
                    values[eventKey][0].runWith(values[eventKey][1]);
                }
            }
        }
    }
}