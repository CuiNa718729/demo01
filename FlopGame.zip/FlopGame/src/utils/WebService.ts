
/**
 * http请求
 */
class WebService {
    public static instance:WebService;
    constructor() {
        
    }

    public static getInstance():WebService{
        if(WebService.instance == null){
            WebService.instance = new WebService();
        }
        return WebService.instance;
    }

    request(url:string , data:any , caller:any , callBack:Function):void{
        var request:Laya.HttpRequest = new Laya.HttpRequest();
        //request.http.timeout = 10000;//设置超时时间
        request.once(Laya.Event.COMPLETE,caller,callBack);
        request.once(Laya.Event.ERROR,this,this.errorHandler);
        request.on(Laya.Event.PROGRESS,this,this.processHandler);
        //192.168.0.42:20181
        //39.107.78.195:20182
        request.send("http://39.107.78.195:20182/" + url , JSON.stringify(data) ,"post","json",["Content-Type","application/json"]);
    }

    //http请求错误
    errorHandler(data:any):void{

    }

    //请求过程
    processHandler(data:any):void{

    }
    
}