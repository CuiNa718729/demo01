
/**
 * 常量定义
*/
class Consts {
    constructor() {
        
    }
    /**
     * Stage Name
    */
    public static S_FlopGame:string = "S_FlopGame";

    /**
     * View Name
    */

    /**
     * Event Name
    */

    /**
     * Http 路径
     */
    public static H_RankingList:string = "ranking/rankingList";
}