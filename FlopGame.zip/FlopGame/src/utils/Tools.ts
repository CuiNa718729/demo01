
/**
 * 工具类
*/
class Tools {
    constructor() {
        
    }

    //获取不重复的随机数
    public static randomNoRepetition(randomArr:Array<any> , total:number , count:number):void{
        var numbers:Array<number> = new Array<number>();
        for (var i:number = 0; i < total ; i++){
            numbers.push(i);
        }
        for (var i:number = 0; i < count; i ++){
            var rd = Math.floor(Math.random() * (total - i));
            randomArr.push(numbers[rd]);
            numbers.splice(rd , 1);
        }
    }

    //比赛时间格式化
    public static matchTimeFormat(time:number):string{
        var msec:string = (time % 1000).toString();
        var second:string = (Math.floor(time / 1000)).toString();
        if(Number(msec) < 10){
            msec = "0" + msec;
        }
        return second + "." + msec + "秒";
    }
}