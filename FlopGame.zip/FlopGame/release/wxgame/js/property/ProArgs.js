var ProArgs = /** @class */ (function () {
    function ProArgs() {
    }
    return ProArgs;
}());
//# sourceMappingURL=ProArgs.js.map