/**
 * 游戏启动页面
 */
var StartView = /** @class */ (function () {
    function StartView() {
    }
    return StartView;
}());
//# sourceMappingURL=StartView.js.map