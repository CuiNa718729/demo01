var GameAttribute = /** @class */ (function () {
    function GameAttribute() {
    }
    return GameAttribute;
}());
//# sourceMappingURL=GameAttribute.js.map