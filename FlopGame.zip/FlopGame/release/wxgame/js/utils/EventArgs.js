/**
 * 事件数据
 */
var EventArgs = /** @class */ (function () {
    function EventArgs() {
    }
    return EventArgs;
}());
//# sourceMappingURL=EventArgs.js.map