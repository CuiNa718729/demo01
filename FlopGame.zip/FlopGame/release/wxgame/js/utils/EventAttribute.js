/**
 * 事件数据
 */
var EventAttribute = /** @class */ (function () {
    function EventAttribute() {
    }
    return EventAttribute;
}());
//# sourceMappingURL=EventAttribute.js.map