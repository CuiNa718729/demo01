/**
 * 事件常量
 */
var Events = /** @class */ (function () {
    function Events() {
    }
    //事件测试
    Events.E_Test = "E_Test";
    return Events;
}());
//# sourceMappingURL=Events.js.map