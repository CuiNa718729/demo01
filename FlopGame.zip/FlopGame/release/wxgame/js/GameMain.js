// 程序入口
var GameMain = /** @class */ (function () {
    function GameMain() {
        Laya.init(750, 1334);
        var testHandler = Laya.Handler.create(this, this.testCallback, null, false);
        var gas = new GameAttribute();
        gas.name = "onepiece";
        EventDispatcher.getInstance().addListener(Consts.S_GameMain, Consts.E_Test, testHandler, gas);
        var gv = new GameView();
        gv.testEvent();
    }
    GameMain.prototype.testCallback = function (args) {
        console.log(args.name);
    };
    return GameMain;
}());
new GameMain();
//# sourceMappingURL=GameMain.js.map