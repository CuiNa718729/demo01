var EventArgs = /** @class */ (function () {
    function EventArgs() {
    }
    return EventArgs;
}());
//# sourceMappingURL=EventArgs.js.map