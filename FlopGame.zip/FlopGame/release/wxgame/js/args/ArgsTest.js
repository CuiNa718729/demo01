/**
 *
 */
var ArgsTest = /** @class */ (function () {
    function ArgsTest() {
    }
    return ArgsTest;
}());
//# sourceMappingURL=ArgsTest.js.map