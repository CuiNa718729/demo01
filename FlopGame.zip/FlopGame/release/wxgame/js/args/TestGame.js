/**
 * game数据
 */
var TestGame = /** @class */ (function () {
    function TestGame() {
    }
    return TestGame;
}());
//# sourceMappingURL=TestGame.js.map