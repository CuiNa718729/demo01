var TestArgsTest = /** @class */ (function () {
    function TestArgsTest(parameters) {
    }
    return TestArgsTest;
}());
//# sourceMappingURL=TestArgsTest.js.map