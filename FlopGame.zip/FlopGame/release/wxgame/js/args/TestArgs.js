/**
 * game数据
 */
var TestArgs = /** @class */ (function () {
    function TestArgs() {
    }
    return TestArgs;
}());
//# sourceMappingURL=TestArgs.js.map