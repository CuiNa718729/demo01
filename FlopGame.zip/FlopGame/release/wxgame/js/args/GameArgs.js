/**
 * game数据
 */
var GameArgs = /** @class */ (function () {
    function GameArgs() {
    }
    return GameArgs;
}());
//# sourceMappingURL=GameArgs.js.map